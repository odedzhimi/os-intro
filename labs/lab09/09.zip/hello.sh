#!/bin/bash
HELLO=Hello
function hello {
local HELLO=Worldlocal HELLO=Worldlocal HELLO=World
echo $HELLO
}
echo $HELLO
hellolocal HELLO=Worldlocal HELLO=Worldlocal HELLO=World
echo $HELLO
}
echo $HELLO
hello
local HELLO=Worldlocal HELLO=Worldlocal HELLO=World
echo $HELLO
}
echo $HELLO
hello
local HELLO=Worldlocal HELLO=Worldlocal HELLO=World
echo $HELLO
}
echo $HELLO
hello

